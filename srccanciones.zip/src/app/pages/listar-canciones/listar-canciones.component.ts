import { Component } from '@angular/core';

@Component({
  selector: 'app-listar-canciones',
  imports: [],
  templateUrl: './listar-canciones.component.html',
  styleUrl: './listar-canciones.component.css'
})
export class ListarCancionesComponent {

}
