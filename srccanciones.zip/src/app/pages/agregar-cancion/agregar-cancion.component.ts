import { Component } from '@angular/core';

@Component({
  selector: 'app-agregar-cancion',
  imports: [],
  templateUrl: './agregar-cancion.component.html',
  styleUrl: './agregar-cancion.component.css'
})
export class AgregarCancionComponent {

}
