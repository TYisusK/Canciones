import { Component } from '@angular/core';

@Component({
  selector: 'app-editar-cancion',
  imports: [],
  templateUrl: './editar-cancion.component.html',
  styleUrl: './editar-cancion.component.css'
})
export class EditarCancionComponent {

}
