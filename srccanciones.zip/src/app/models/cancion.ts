export class Empleado {
    titulo!: string;
    autor!: string;
    genero!: string;
    cancionAudio!: string;
}